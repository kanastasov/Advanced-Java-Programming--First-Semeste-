package uk.ac.tees.u0022190;

import java.io.File;
import javax.swing.ImageIcon;

/**
 * <p>A class representing a Colonel (a really experienced soldier) in a video
 * game.</p>
 *
 * <p>This program is part of AJP-P2-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P2-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 12-Oct-2012 </p>
 */
public class Colonel extends Soldier {

    /**
     * These is the default points value for a GDI colonel.
     */
    final int gdiPoints = 100;
    
    /**
     * These is the default points value for a NOD colonel.
     */
    final int nodPoints = 95;
    
    /**
     * These is the default points value for a SCRIN colonel.
     */
    final int scrinPoints = 90;

    /**
     * Initialises the Colonel object with the correct points value, depending on
     * faction.
     *
     * @param f the faction the colonel belongs to
     */
    public Colonel(Faction f) {
        super(f);
        String imageName = "colonel.png";
        switch (f) {
            case GDI:
                points = gdiPoints;
                imageName = "gdi-" + imageName;
                break;
            case NOD:
                points = nodPoints;
                imageName = "nod-" + imageName;
                break;
            case SCRIN:
                points = scrinPoints;
                imageName = "scrin-" + imageName;
                break;
            default:
                System.err.println("Faction unknown");
        }
        image = new ImageIcon("images" + File.separator + imageName);
    }

    @Override
    public String kill() {
        Soldier.addPoints(points);
        return "A " + faction.name() + " colonel retires, permanently: +" + points + "pts.\n";
    }
}