package uk.ac.tees.u0022190;

import java.io.File;
import javax.swing.ImageIcon;

/**
 * <p>A class representing a major (an experienced soldier) in a video game.</p>
 *
 * <p>This program is part of AJP-P2-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P2-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 12-Oct-2012 </p>
 */
public class Major extends Soldier {

    /**
     * These is the default points value for a GDI major.
     */
    final int gdiPoints = 55;
    
    /**
     * These is the default points value for a NOD major.
     */
    final int nodPoints = 60;
    
    /**
     * These is the default points value for a SCRIN major.
     */
    final int scrinPoints = 70;

    /**
     * Initialises the Major object with the correct points value, depending on
     * faction.
     *
     * @param f the faction the major belongs to
     */
    public Major(Faction f) {
       super(f);
        String imageName = "major.png";
        switch (f) {
            case GDI:
                points = gdiPoints;
                imageName = "gdi-" + imageName;
                break;
            case NOD:
                points = nodPoints;
                imageName = "nod-" + imageName;
                break;
            case SCRIN:
                points = scrinPoints;
                imageName = "scrin-" + imageName;
                break;
            default:
                System.err.println("Faction unknown");
        }
        image = new ImageIcon("images" + File.separator + imageName);
    }

    @Override
    public String kill() {
        Soldier.addPoints(points);
        return "A " + faction.name() + " major explodes into pieces: +" + points + "pts.\n";
    }
}