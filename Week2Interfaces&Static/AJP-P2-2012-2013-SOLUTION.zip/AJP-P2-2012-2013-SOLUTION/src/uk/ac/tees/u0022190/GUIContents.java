package uk.ac.tees.u0022190;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * <p>A simple GUI that demonstrates the Killable interface.</p>
 *
 * <p>This program is part of AJP-P2-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P2-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 12-Oct-2012 </p>
 */
class GUIContents extends JPanel implements ActionListener {

    /**
     * An array of labels that will hold the images of soldiers and vehicles.
     */
    private JLabel[] labels;
    
    /**
     * The number of labels in the GUI displaying soldier/vehicle images.
     */
    final int numLabels = 5;
    
    /**
     * The current high score.
     */
    private int max = 0;

    /**
     * A list of the units killed.
     */
    private ArrayList<Killable> fatalities = new ArrayList<Killable>();
    
    /**
     * A label which displays the current score and top score.
     */
    private JLabel status;
    
    /**
     * A blank image, used as a space filler.
     */
    private ImageIcon blank = new ImageIcon("images" + File.separator + "blank.png");
    
    /**
     * A random number generator.
     */
    private final Random r = new Random();

    /**
     * Sets up the GUI and places the labels in their starting (blank) state.
     */
    public GUIContents() {
        // Configure layout of JPanel
        this.setLayout(new BorderLayout());

        // Configure status label and add to north of JPanel
        status = new JLabel("Current score: 0 \t High score: 0");
        this.add(status, BorderLayout.NORTH);

        // Configure button and add to center of JPanel
        final JButton redButton = new JButton(new ImageIcon("images" 
                + File.separator + "button.png"));
        redButton.addActionListener(this);
        redButton.setBackground(Color.white);
        this.add(redButton, BorderLayout.CENTER);

        /* Configure an array of JLabels that will contain the images. Add to an 
         * internal JPanel using grid layout. 
         */
        labels = new JLabel[numLabels];
        final JPanel jp = new JPanel(new GridLayout(1, numLabels));
        for (int counter = 0; counter < numLabels; counter++) {
            labels[counter] = new JLabel(blank);
            jp.add(labels[counter]);
        }

        // Add internal JPanel to (this) Jpanel
        this.add(jp, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        // Clear casulaties from last round
        fatalities.clear();
        
        // Determine the number of casualties this round
        final int numCasualties = r.nextInt(numLabels) + 1;

        // Execute this loop once for each casualty
        for (int i = 0; i < numCasualties; i++) {

            switch (getRandomUnitType()) {
                case CADET:
                    fatalities.add(new Cadet(getRandomFaction()));
                    break;
                case MAJOR:
                    fatalities.add(new Major(getRandomFaction()));
                    break;
                case COLONEL:
                    fatalities.add(new Colonel(getRandomFaction()));
                    break;
                case LIGHTTANK:
                    fatalities.add(new LightTank(getRandomFaction()));
                    break;
                case HEAVYTANK:
                    fatalities.add(new HeavyTank(getRandomFaction()));
                    break;
                default:
                    System.err.println("Unit unknown");
                    break;
            }
        }

        // Add the correct images to the GUI. Note I added this method to the interface.
        for (int i = 0; i < fatalities.size(); i++) {
            labels[i].setIcon(fatalities.get(i).getImage());
        }
        
        // Fill remaining Jlabels with a blank image to prevent gaps in GUI
        for (int counter = fatalities.size(); counter < numLabels; counter++) {
            labels[counter].setIcon(blank);
        }
        
        // Find out total score by iterating through list. Note I have added a 
        // method to the interface to simplify this.
        int total = 0;
        for (Killable k : fatalities) {
            total += k.getPoints();
        }

        // Check to see if we have beaten top score, if so update
        max = (total > max) ? total : max;

        // Update status label
        status.setText("Current score: " + total + "\t High score:" + max);
    }
    
    /** Gets a random Faction.
     * 
     * @return a Faction 
     */
    private Faction getRandomFaction() {
        return Faction.values()[r.nextInt(Faction.values().length)];
    }
    
    /** Gets a random Unit type.
     * 
     * @return a unit type
     */
    private UnitType getRandomUnitType() {
        return UnitType.values()[r.nextInt(UnitType.values().length)];
    }
}

/** An enumeration of the various unit types in a video game.
 * 
 * @author Mark Truran m.a.truran@tees.ac.uk
 */
enum UnitType {
    /**
     * An inexperienced soldier.
     */
    CADET, 
    /**
     * An experienced soldier.
     */
    MAJOR, 
    /**
     * A very experienced soldier.
     */
    COLONEL,
    /**
     * A lightly armoured tank.
     */
    LIGHTTANK, 
    /**
     * A heavily armoured tank.
     */
    HEAVYTANK
}
