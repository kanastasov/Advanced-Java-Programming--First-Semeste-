package uk.ac.tees.u0022190;

import javax.swing.ImageIcon;

/** <p>An abstract class representing one soldier in a video game.</p>
 *
 * <p>This program is part of AJP-P2-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P2-2012-2013-SOLUTION is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 12-Oct-2012 </p>
 */
public abstract class Soldier implements Killable {

    /**
     * The points cost of all soldiers killed in the engagement.
     */
    static int totalPoints = 0;
    
    /** 
     * The number of points a player would get for killing this soldier. 
     */
    protected int points;
    
    /**
     * The faction this soldier belongs to.
     */
    protected Faction faction;
    
    /** 
     * A picture of the soldier. 
     */
    protected ImageIcon image;

    /** Constructor initialises the Soldier object with the correct faction.
     * 
     * @param faction The faction the soldier belongs to
     */
    public Soldier(Faction faction) {
        this.faction = faction;
    }

    /** A method that returns the number of points a player gets for killing 
     * this soldier.
     * 
     * @return the number of points a player gets for killing this soldier
     */
    @Override
    public int getPoints() {
        return points;
    }

    /** A method to increase the global counter.
     * 
     * @param fatality the points value of the recent fatality 
     */
    public static void addPoints(int fatality) {
        Soldier.totalPoints += fatality;
    }

    /** This methods returns a picture representing the soldier.
     * 
     * @return a PNG image file
     */
    @Override
    public ImageIcon getImage() {
        return image;
    }
    
}