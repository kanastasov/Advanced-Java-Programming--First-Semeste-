package uk.ac.tees.u0022190;

import uk.ac.tees.u0022190.PizzaSorter;
import uk.ac.tees.u0022190.Pizza;
import java.io.File;
import java.util.ArrayList;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * <p>A set of tests to check the output of PizzaSorter.</p>
 *
 * <p>This program is part of AJP-P1-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 03-Oct-2012 </p>
 */
public class PizzaSorterTest {

    /**
     * The radius, in inches, of a small pizza.
     */
    final static int SMALL = 9;
    
    /**
     * The radius, in inches, of a medium pizza.
     */
    final static int MEDIUM = 12;
    
    /**
     * The radius, in inches, of a large pizza.
     */
    final static int LARGE = 15;

    /**
     * Testing the parse method with a valid file.
     */
    @Test
    public void testParseValidFile() {

        System.out.println("Parsing valid file");
        final PizzaSorter ps = new PizzaSorter();
        final ArrayList<Pizza> listOfPizzas = ps.parseFile(new File("pizza.txt"));
        final int expectedResult = 9;
        final int actualResult = listOfPizzas.size();
        assertEquals(expectedResult, actualResult);
    }
    
    /**
     * Testing the parse method with a invalid file.
     */
    @Test
    public void testParseInvalidFileName() {

        System.out.println("Parsing non-existent file");
        final PizzaSorter ps = new PizzaSorter();
        final ArrayList<Pizza> listOfPizzas = ps.parseFile(new File("non-existent.txt"));
        assertNull(listOfPizzas);
    }
    
    /**
     * Testing the parse method with a valid file containing invalid data.
     */
    @Test
    public void testParseInvalidData() {

        System.out.println("Parsing file with invalid data");
        final PizzaSorter ps = new PizzaSorter();
        final ArrayList<Pizza> listOfPizzas = ps.parseFile(new File("wrong-num.txt"));
        assertNull(listOfPizzas);
    }

    /**
     * Testing  the listAllPizzas method.
     */
    @Test
    public void testListAllPizzas() {
        
        System.out.println("Listing all pizzas");
        String actualResult, expectedResult;
        final PizzaSorter ps = new PizzaSorter();
        expectedResult = ps.listAllPizzas("pizza.txt");
        actualResult = "A pizza (9 inches) with cheese and tomato\nA pizza "
                + "(12 inches) with chicken and mushroom and a cheese crust\nA "
                + "pizza (15 inches) with sausage and bacon and a cheese "
                + "crust, deep-pan\nA pizza (12 inches) with ham and tomato "
                + "and a spicy crust\nA pizza (9 inches) with ham and mushroom\nA "
                + "pizza (12 inches) with sweetcorn and peppers and a cheese "
                + "crust\nA pizza (15 inches) with tuna and sweetcorn and a "
                + "spicy crust, thin-pan\nA pizza (9 inches) with banana "
                + "and pineapple\nA pizza (12 inches) with ham and pineapple "
                + "and a cheese crust\n";
        //System.out.println(expectedResult);
        //System.out.println(actualResult);
        assertEquals(expectedResult, actualResult);
    }

    /**
     * Testing the filterPizzas method, radius 9.
     */
    @Test
    public void testFilterPizzas9() {
        
        System.out.println("Listing all pizzas with radius 9in.");
        String actualResult, expectedResult;
        final PizzaSorter ps = new PizzaSorter();
        expectedResult = "A pizza (9 inches) with cheese and tomato\n"
                + "A pizza (9 inches) with ham and mushroom\nA pizza "
                + "(9 inches) with banana and pineapple\n";
        actualResult = ps.filterPizzas("pizza.txt", SMALL);
        //System.out.println(expectedResult);
        //System.out.println(actualResult);
        assertEquals(actualResult, expectedResult);
    }
    
    /**
     * Testing the filterPizzas method, radius 12.
     */
    @Test
    public void testFilterPizzas12() {
        
        System.out.println("Listing all pizzas with radius 12in.");
        String actualResult, expectedResult;
        final PizzaSorter ps = new PizzaSorter();
        expectedResult = "A pizza (12 inches) with chicken and mushroom and a cheese crust\nA "
                + "pizza (12 inches) with ham and tomato and a spicy crust\nA "
                + "pizza (12 inches) with sweetcorn and peppers and a cheese crust\nA "
                + "pizza (12 inches) with ham and pineapple and a cheese crust\n";
        actualResult = ps.filterPizzas("pizza.txt", MEDIUM);
        //System.out.println(expectedResult);
        //System.out.println(actualResult);
        assertEquals(actualResult, expectedResult);
    }
    
    /**
     * Testing the filterPizzas method, radius 15.
     */
    @Test
    public void testFilterPizzas15() {
        
        System.out.println("Listing all pizzas with radius 15in.");
        String actualResult, expectedResult;
        final PizzaSorter ps = new PizzaSorter();
        expectedResult = "A pizza (15 inches) with sausage and bacon and a "
                + "cheese crust, deep-pan\nA pizza (15 inches) with "
                + "tuna and sweetcorn and a spicy crust, thin-pan\n";
        actualResult = ps.filterPizzas("pizza.txt", LARGE);
        //System.out.println(expectedResult);
        //System.out.println(actualResult);
        assertEquals(actualResult, expectedResult);
    }
}
