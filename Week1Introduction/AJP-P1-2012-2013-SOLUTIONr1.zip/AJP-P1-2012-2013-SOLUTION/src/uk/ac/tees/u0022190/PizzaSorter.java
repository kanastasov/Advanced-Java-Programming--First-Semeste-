package uk.ac.tees.u0022190;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * <p>This class reads a data file and returns a human readable list of
 * pizzas.</p>
 *
 * <p>This program is part of AJP-P1-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 03-Oct-2012 </p>
 */
public class PizzaSorter {

    /**
     * No-args constructor.
     */
    public PizzaSorter() {
    }

    /**
     * This method parses the named data file and creates pizza objects.
     *
     * @param file the file containing the data
     * @return an array list of pizza objects
     */
    public ArrayList<Pizza> parseFile(File file) {

        ArrayList<Pizza> listOfPizzas = new ArrayList<Pizza>();
        final int small = 9;
        final int medium = 12;
        final int large = 15;

        try {
            final Scanner fileScanner = new Scanner(file);

            while (fileScanner.hasNext()) {

                switch (fileScanner.nextInt()) {
                    case small:
                        listOfPizzas.add(new SmallPizza(small, fileScanner.next(), fileScanner.next()));
                        break;
                    case medium:
                        listOfPizzas.add(new MediumPizza(medium, fileScanner.next(), fileScanner.next(), fileScanner.next()));
                        break;
                    case large:
                        listOfPizzas.add(new LargePizza(large, fileScanner.next(), fileScanner.next(), fileScanner.next(), fileScanner.next()));
                        break;
                    default:
                        // Invalid data!
                        return null;
                }
            }
            fileScanner.close();

        } catch (FileNotFoundException fnfe) {
            // Non-existent text file!
            return null;
        }
        return listOfPizzas;
    }

    /**
     * This method returns a list of all the pizzas in the named data file.
     *
     * @param fileName The name of the file containing the data
     * @return A list of pizzas
     */
    public String listAllPizzas(final String fileName) {

        final ArrayList<Pizza> listOfPizzas = this.parseFile(new File(fileName));
        final StringBuilder sb = new StringBuilder();

        for (int i = 0; i < listOfPizzas.size(); i++) {
            sb.append(listOfPizzas.get(i).toString());
            sb.append("\n");
        }
        return sb.toString();
    }

    /**
     * This method returns a list of all the pizzas of a given size.
     *
     * @param fileName The name of the file containing the data
     * @param radius the radius of the pizza
     * @return A list of pizzas
     */
    public String filterPizzas(final String fileName, int radius) {

        final ArrayList<Pizza> listOfPizzas = this.parseFile(new File(fileName));
        final StringBuilder sb = new StringBuilder();

        for (int i = 0; i < listOfPizzas.size(); i++) {
            if (listOfPizzas.get(i).getRadius() == radius) {
                sb.append(listOfPizzas.get(i).toString());
                sb.append("\n");
            }
        }
        return sb.toString();
    }
}