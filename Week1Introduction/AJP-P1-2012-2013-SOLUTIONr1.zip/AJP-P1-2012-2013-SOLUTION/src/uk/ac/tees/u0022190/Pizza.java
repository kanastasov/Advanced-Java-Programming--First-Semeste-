package uk.ac.tees.u0022190;

/**
 * <p>This abstract class represents a single, generic pizza. All pizzas have a 
 * radius and two toppings.</p>
 *
 * <p>This program is part of AJP-P1-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 03-Oct-2012 </p>
 */
public abstract class Pizza {

    /**
     * The radius of the pizza, in inches.
     */
    protected int radius;
    
    /**
     * The first pizza topping.
     */
    protected String topping1;
    
    /**
     * The second pizza topping.
     */
    protected String topping2;

    /** Initialises a generic pizza object.
     * 
     * @param radius  the radius of the pizza
     * @param topping1 the first topping on the pizza
     * @param topping2 the second topping on the pizza
     */
    public Pizza(int radius, String topping1, String topping2) {
        this.radius = radius;
        if (topping1 == null) {
            this.topping1 = "cheese";
        } else {
            this.topping1 = topping1;
        }
        if (topping2 == null) {
            this.topping2 = "tomato";
        } else {
            this.topping2 = topping2;
        }
    }
    
    /** This method gets the radius of the pizza, in inches.
     * 
     * @return the radius of the pizza, in inches
     */
    public int getRadius() {
        return radius;
    }
            
    /**
     * This method returns a textual description of the pizza.
     *
     * @return A textual description of the pizza
     */
    @Override
    public String toString() {
        return "A pizza (" + radius + " inches) with " + topping1 + " and " + topping2;
    }
}