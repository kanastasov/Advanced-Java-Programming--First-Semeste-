package uk.ac.tees.u0022190;

/**
 * This class represents a large (15 inch) pizza. A large pizza has 2 toppings, 
 * a special crust and a choice of crust thickness.
 *
 * <p>This program is part of AJP-P1-2012-2013-SOLUTION.</p>
 *
 * <p>AJP-P1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Mark Truran m.a.truran@tees.ac.uk 03-Oct-2012 </p>
 */
public class LargePizza extends Pizza {

    /**
     * The type of pizza crust.
     */
    private String crust;
    
    /**
     * The thickness of the pizza.
     */
    private String thickness;

    /**
     * Initialises a large pizza object.
     *
     * @param radius the radius of the pizza, in inches
     * @param topping1 the first topping on the pizza
     * @param topping2 the second topping on the pizza
     * @param crust the type of pizza crust
     * @param thickness the thickness of the pizza crust
     */
    public LargePizza(int radius, String topping1, String topping2, String crust, String thickness) {
        super(radius, topping1, topping2);
        if (crust == null) {
            this.crust = "cheese";
        } else {
            this.crust = crust;
        }
        if (thickness == null) {
            this.crust = "thin-pan";
        } else {
            this.thickness = thickness;
        }
    }

    @Override
    public String toString() {
        return super.toString() + " and a " + crust + " crust, " + thickness;
    }
}